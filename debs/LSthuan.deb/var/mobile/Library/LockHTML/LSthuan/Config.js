// Configuration here //

var twentyfour = false;
var padzero = true;
var refresh = 5000;

var weathercode = 'VMXX0139'; // go to weather.com to get your city's code, the code is in the url
var celsius = true;
var gpsswitch = false; //must use widget weather xml if set to true
var refreshrate = 10;

var language = "en"; // en, cz, it, sp, de, fr, zh 
